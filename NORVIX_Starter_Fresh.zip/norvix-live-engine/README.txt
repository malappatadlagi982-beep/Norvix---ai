NORVIX LIVE ENGINE — STARTER PROJECT

What it does
- Mobile-friendly NORVIX web app.
- Sends every question to Tavily Search for fresh web results.
- Sends the question plus search extracts to Gemini for a grounded answer.
- Shows source links and a local time for when the search completed.
- Keeps API keys on the server, not in browser code.

SETUP
1. Create Gemini and Tavily API keys from their official websites.
2. Copy .env.example to a new file named .env.
3. Put your keys in .env. Never share .env or upload it publicly.
4. Install Node.js on a computer or use a trusted cloud development environment.
5. In this project folder run:
   npm install
   npm start
6. Open the local address shown by the server.

PHONE-ONLY NOTE
This is the code project, but running a Node server needs a hosted Node environment or a computer.
You can edit files from Android, but don't paste API keys into public frontend code.
Free hosting and API quotas can change and may require account setup.

NEXT FEATURES (not included yet)
- Secure video upload and Gemini video analysis.
- YouTube Analytics integration with explicit account permission.
- Saved creator profiles and schedules.
- Trend history and richer fact checking.

API references
- Gemini generateContent: https://ai.google.dev/api/generate-content
- Tavily Search: https://help.tavily.com/articles/4840311948-tavily-search-api
