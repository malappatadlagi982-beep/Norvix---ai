import express from "express";
import dotenv from "dotenv";

dotenv.config();
const app = express();
app.use(express.json({ limit: "1mb" }));
app.use(express.static("public"));

const { GEMINI_API_KEY, TAVILY_API_KEY } = process.env;
const MODEL = process.env.GEMINI_MODEL || "gemini-flash-latest";

const NORVIX_SYSTEM = `
You are NORVIX, a thoughtful, practical AI coach for YouTube and video creators.
Help beginners, growing creators, and professionals. Be honest, supportive, and specific.
For video advice, consider the human viewer: curiosity, clarity, emotion, pacing, trust,
accessibility, and whether the video delivers its promise. Never guarantee views, virality,
subscriber growth, or algorithm outcomes. Do not invent platform rules or analytics.
When web sources are supplied, use them for current claims, distinguish publication dates
from the time checked, cite sources by their supplied title and URL, and say when evidence
is limited or conflicting. Prefer actionable steps over vague "secret hacks".
`;

async function searchWeb(query) {
  if (!TAVILY_API_KEY) return [];
  const response = await fetch("https://api.tavily.com/search", {
    method: "POST",
    headers: {
      "Content-Type": "application/json",
      "Authorization": `Bearer ${TAVILY_API_KEY}`
    },
    body: JSON.stringify({
      query,
      topic: "general",
      search_depth: "basic",
      max_results: 5,
      include_answer: false
    })
  });
  if (!response.ok) {
    const detail = await response.text();
    throw new Error(`Live search failed (${response.status}): ${detail.slice(0, 250)}`);
  }
  const data = await response.json();
  return (data.results || []).map(item => ({
    title: item.title,
    url: item.url,
    content: item.content,
    published_date: item.published_date || null
  }));
}

app.post("/api/ask", async (req, res) => {
  try {
    const question = String(req.body?.question || "").trim();
    if (!question) return res.status(400).json({ error: "Please enter a question." });
    if (question.length > 4000) return res.status(400).json({ error: "Question is too long." });
    if (!GEMINI_API_KEY) return res.status(503).json({ error: "Gemini API key is missing. Add it to your private .env file." });
    if (!TAVILY_API_KEY) return res.status(503).json({ error: "Live search key is missing. Add TAVILY_API_KEY to your private .env file." });

    // NORVIX searches for every question so answers can use fresh sources.
    const sources = await searchWeb(question);
    const sourceText = sources.map((s, i) =>
      `[${i + 1}] ${s.title}\nURL: ${s.url}\nPublished: ${s.published_date || "Date not supplied"}\nExtract: ${s.content}`
    ).join("\n\n");

    const prompt = `
User question: ${question}

Fresh web search results (retrieved just now):
${sourceText || "No search results were returned."}

Answer the user using the search results where relevant. For general creator coaching,
you may also use your expertise, but label opinions as recommendations. If sources do
not support a current fact, say so. End with a short Sources list containing the URLs
of the sources actually used. Do not claim that search-result snippets prove more than
they show.
`;
    const aiResponse = await fetch(
      `https://generativelanguage.googleapis.com/v1beta/models/${encodeURIComponent(MODEL)}:generateContent?key=${encodeURIComponent(GEMINI_API_KEY)}`,
      {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          systemInstruction: { parts: [{ text: NORVIX_SYSTEM }] },
          contents: [{ role: "user", parts: [{ text: prompt }] }],
          generationConfig: { temperature: 0.6, maxOutputTokens: 1400 }
        })
      }
    );
    if (!aiResponse.ok) {
      const detail = await aiResponse.text();
      return res.status(502).json({ error: `AI request failed (${aiResponse.status}). Check your model name, key and free-tier limits.`, detail: detail.slice(0, 300) });
    }
    const data = await aiResponse.json();
    const answer = data.candidates?.[0]?.content?.parts?.map(p => p.text || "").join("").trim();
    if (!answer) return res.status(502).json({ error: "The AI returned an empty answer. Please try again." });

    res.json({
      answer,
      checkedAt: new Date().toISOString(),
      sources: sources.map(({ title, url, published_date }) => ({ title, url, published_date }))
    });
  } catch (error) {
    console.error(error);
    res.status(500).json({ error: error.message || "Something went wrong." });
  }
});

app.get("/api/health", (_req, res) => res.json({ ok: true, app: "NORVIX" }));

const port = Number(process.env.PORT || 3000);
app.listen(port, () => console.log(`NORVIX running at http://localhost:${port}`));
